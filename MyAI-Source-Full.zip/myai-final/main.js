const { app, BrowserWindow, ipcMain, shell } = require('electron')
const path = require('path')

let win

function createWindow() {
  win = new BrowserWindow({
    width: 1140,
    height: 760,
    minWidth: 860,
    minHeight: 600,
    frame: false,
    transparent: false,
    backgroundColor: '#0b0d18',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    show: false,
    titleBarStyle: 'hidden',
  })

  win.loadFile(path.join(__dirname, 'assets', 'index.html'))

  win.once('ready-to-show', () => win.show())
  win.on('closed', () => { win = null })
}

ipcMain.on('win-close',    () => win && win.close())
ipcMain.on('win-minimize', () => win && win.minimize())
ipcMain.on('win-maximize', () => {
  if (!win) return
  win.isMaximized() ? win.unmaximize() : win.maximize()
})

app.whenReady().then(createWindow)
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit() })
app.on('activate', () => { if (!win) createWindow() })
